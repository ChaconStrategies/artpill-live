module.exports = {

"[project]/src/components/custom-cursor.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_a03af892._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/custom-cursor.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};