module.exports = {

"[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[turbopack]_browser_dev_hmr-client_hmr-client_ts_59fa4ecd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-ssr] (ecmascript)");
    });
});
}}),
"[project]/src/components/webgl-scene.tsx [app-ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_three_build_three_core_a75ea919.js",
  "server/chunks/ssr/node_modules_three_build_three_module_bc28cc46.js",
  "server/chunks/ssr/node_modules_three_build_three_module_c9a5c6ae.js",
  "server/chunks/ssr/node_modules_react-reconciler_4b3d0196._.js",
  "server/chunks/ssr/node_modules_@react-three_fiber_dist_6bc10de6._.js",
  "server/chunks/ssr/node_modules_4e5a19d8._.js",
  "server/chunks/ssr/src_components_webgl-scene_tsx_f793106e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/webgl-scene.tsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};