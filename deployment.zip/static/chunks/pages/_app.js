__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__63416926._.js",
  "static/chunks/node_modules_react_b2385d85._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_59c12e99._.js",
  "static/chunks/[root of the server]__49fd8634._.js",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_14f09d89._.js"
])
