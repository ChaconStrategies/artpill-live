(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_887b119b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_887b119b._.js",
  "chunks": [
    "static/chunks/src_components_webgl-scene_tsx_dbad14ba._.js",
    "static/chunks/src_a3ef1e23._.js",
    "static/chunks/node_modules_4fa36b86._.js"
  ],
  "source": "dynamic"
});
