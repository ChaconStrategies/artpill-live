(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_custom-cursor_tsx_8ca88f4a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_custom-cursor_tsx_8ca88f4a._.js",
  "chunks": [
    "static/chunks/_9c92cae2._.js"
  ],
  "source": "dynamic"
});
