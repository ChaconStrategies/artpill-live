(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_custom-cursor_tsx_06ddd592._.js", {

"[project]/src/components/custom-cursor.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_9c92cae2._.js",
  "static/chunks/src_components_custom-cursor_tsx_8ca88f4a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/custom-cursor.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);