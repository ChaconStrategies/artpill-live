(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/src_app_c1b84f05._.css",
    "static/chunks/src_components_custom-cursor_tsx_06ddd592._.js",
    "static/chunks/node_modules_next_0e02cc1e._.js",
    "static/chunks/src_components_456930af._.js"
  ],
  "source": "dynamic"
});
