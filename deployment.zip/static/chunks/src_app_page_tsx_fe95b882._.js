(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_fe95b882._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_fe95b882._.js",
  "chunks": [
    "static/chunks/node_modules_f2633810._.js",
    "static/chunks/src_a3ef1e23._.js"
  ],
  "source": "dynamic"
});
