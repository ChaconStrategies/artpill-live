(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_webgl-scene_tsx_388ea9ea._.js", {

"[project]/src/components/webgl-scene.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_three_build_three_core_df0bde7e.js",
  "static/chunks/node_modules_three_build_three_module_230a9f89.js",
  "static/chunks/node_modules_three_build_three_module_90b4155f.js",
  "static/chunks/node_modules_react-reconciler_25c8ec02._.js",
  "static/chunks/node_modules_@react-three_fiber_dist_3ed27848._.js",
  "static/chunks/node_modules_2760b7b0._.js",
  "static/chunks/src_components_webgl-scene_tsx_a93d262c._.js",
  "static/chunks/src_components_webgl-scene_tsx_3854f75c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/webgl-scene.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);